package ProblemSolving;

public class problem1 {

}
