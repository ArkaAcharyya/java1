package ProblemSolving;

public class problem3 {

}
